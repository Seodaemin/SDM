package com.zerock.util;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect //Aspect클래스를 의미
@Component //bean클래스의 자동생성
public class LogAdvice {

	//공통코드가 들어간다
	@Before("execution(* com.zerock.board.service.BoardServiceImpl*.*(..))")// *(..)뒤에 있는 모든 메서드를 의미함
	public void beforeLog() {
		
		System.out.println("log:--------메서드 실행전-----------");
		
	}
	
	@After("execution(* com.zerock.board.service.BoardServiceImpl*.*(..))")
	public void afterLog() {
		
		System.out.println("log:--------메서드 실행후-----------");
	}
	
	@Around("execution(* com.zerock.board.service.BoardServiceImpl*.*(..))")
	public Object arountLog(ProceedingJoinPoint jp) {
		
		long start = System.currentTimeMillis();
		
		System.out.println("적용 클래스:"+jp.getTarget());// 어떤 메서드가 실행되는지 확인
		System.out.println("적용 파라미터:"+Arrays.toString(jp.getArgs()));//해당 메서드의 파라미터 값을 확인
		Object result = null;
		
		
		try {
			result = jp.proceed();//proceed()메서드는 타겟이 되는  메서드의 실행을 의미. 해당메서드를 실행시켜야 타겟메서드가 실행
		} catch (Throwable e) {
			
			e.printStackTrace();
		}
		long end = System.currentTimeMillis();
		
		System.out.println("메서드 수행에 걸린 시간:"+(end-start)*0.001);
		
		return result;
		
		
	}
}
