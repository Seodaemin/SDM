package com.zerock.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoginInterceptor extends HandlerInterceptorAdapter {
	
	//1. 스프링에서 제공하는 HandlerInterceptorAdapter클래스를 상속
	//2. 핸들러인터셉터 어댑터가 가지고 있는 3가지 메서드를 오버라이딩 해서 사용합니다
	//3. alt + shift + s -> overriding method

	
	//preHandle 메서드는 컨트롤러를 실행하기 전에 요청을 가로채서 처리한다
	//일반적으로 로그인, 세션처리에 사용된다
	//이후에 스프링 설정파일에 인터셉터를 적용
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		//세션에 대한 정보 얻어옴
				HttpSession session = request.getSession();
				String user_id = (String)session.getAttribute("user_id");
				
				if(user_id == null) {
					response.sendRedirect("/MyWeb/session/loginPage"); //절대경로
					return false; //핸들러 메서드 실행후에, Controller를 실행하지 않음
				} else {
					return true; //return true의 의미는 Controller를 정상 실행
				}
				
			}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
	
		super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
		super.afterCompletion(request, response, handler, ex);
	}

	
}
