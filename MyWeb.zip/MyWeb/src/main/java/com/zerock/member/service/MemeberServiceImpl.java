package com.zerock.member.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zerock.member.command.MemberVO;
import com.zerock.member.mapper.MemberMapper;

@Service
public class MemeberServiceImpl implements MemberService{

	@Autowired
	private MemberMapper mapper;
	
	@Override
	public int checkId(String id) {
		
		int result = mapper.checkId(id);
		
		return result;
	}

	//회원가입 처리
	@Override
	public int join(MemberVO vo) {
		
		int result =mapper.join(vo);
		
		return result;
	}
	
	//로그인
	@Override
	public int login(MemberVO vo) {

		int result = mapper.login(vo);
		System.out.println("성공실패?:" + result);

		return result;
	}
}
