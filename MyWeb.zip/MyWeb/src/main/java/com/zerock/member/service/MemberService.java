package com.zerock.member.service;

import com.zerock.member.command.MemberVO;

public interface MemberService {
	//추상메서드
	public int checkId(String id);// 아이디 중복 체크
	public int join(MemberVO vo); //회원가입 기능
	public int login(MemberVO vo); //로그인
}
