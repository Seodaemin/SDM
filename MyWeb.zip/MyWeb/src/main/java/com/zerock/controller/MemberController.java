package com.zerock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zerock.member.command.MemberVO;
import com.zerock.member.service.MemberService;

@Controller
@RequestMapping("/member/*")
public class MemberController {

	
//  로그인 테이블
//	create table member(
//			id varchar(50) primary key,
//		    pw varchar(50),
//		    name varchar(50),
//		    regdate datetime default current_timestamp);
	
	@Autowired
	private MemberService member;
	//로그인 화면처리
	@RequestMapping("/login")
	public String login() {
		return "member/login";
	}
	
	//회원가입 처리
	@RequestMapping("/join")
	public String join() {
		return "member/join";
	}
	
	//ajax요청 받기
	@RequestMapping("/checkId")
	@ResponseBody
	//메서드에 @ResponseBody가 붙으면 리턴하는 값을 View리졸버로 보내지 않고 
	//해당메서드를 호출한 곳으로 결과를 반환한다
	public int checkId(@RequestParam("id") String id) {
		
		int result = member.checkId(id);
		System.out.println("아이디 개수 : " + result);
		return result;
	}
	
	//join폼 요청 처리
	@RequestMapping("/joinForm")
	public String joinForm(MemberVO vo,
			RedirectAttributes RA
			) {
		
		int result = member.join(vo);
		
		if(result == 1) {//회원가입 성공
			RA.addFlashAttribute("msg","회원가입에 성공했습니다"); //일회성 데이터
		}else {//회원가입 실패
			RA.addFlashAttribute("msg", "회원가입에 실패했습니다");
		}
		
		return "redirect:/member/login";
		
	
}
	//login 폼 처리
		@RequestMapping("/loginForm")
		public String loginForm(MemberVO vo, HttpSession session, RedirectAttributes RA) {
			//MemberVO 커맨드객체사용, 세션 사용, 리다이렉트어트리뷰트 사용
			
			
			int result = member.login(vo);


			if(result == 1) { //1개의 카운트가 나왔다는 것은 로그인 성공
				
				RA.addFlashAttribute("msg","로그인에 성공 하셨습니다");
				session.setAttribute("user_id", vo.getId()); //세션에 아이디 저장
				
				return "redirect:/"; //Home컨트롤러의 맵핑으로
				//로그인 성공시 우측 상단의 정보를 변경하기 위해 header파일의 세션처리
				//또한 로그인한 정보가 없다면, 게시글 작성, 변경, 삭제할 수 없도록 BoardInterceptor생성
				
			} else { //로그인 실패
				RA.addFlashAttribute("msg", "아이디 비밀번호를 다시 확인해주세요"); //1회성 데이터에 msg저장
				return "redirect:/member/login"; //다시 로그인 화면으로
			}

		}
		//로그아웃
		@RequestMapping("/logout")
		public String logout(HttpSession session) {
			session.invalidate();

			return "redirect:/";
		}
}
