package com.zerock.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.zerock.board.command.BoardVO;
import com.zerock.board.command.Criteria;
import com.zerock.board.command.PageVO;
import com.zerock.board.service.BoardService;

// /board/list 요청이 들어오면 list.jsp화면처리
// /board/register 요청이 들어오면 register.jsp화면처리
///board/content 요청이 들어오면 content.jsp화면처리
///board/modify 요청이 들어오면 modify.jsp화면처리

@Controller
@RequestMapping("/board/*")
public class BoardController {
	/* 테이블 설정
	  create table tbl_board(
		num int auto_increment primary key,
    	title varchar(200) not null,
    	content varchar(2000) not null,
    	wirter varchar(50) not null,
    	regdate datetime default current_timestamp,
    	updatedate datetime default current_timestamp);
	 */
	
	@Autowired
	private BoardService service;
	
//	//목록 화면처리
//	@RequestMapping("/list")
//	public String list(Model model) {
//		//게시글 목록 가져오기
//		ArrayList<BoardVO> list = service.getList();
//		
//		//모델 객체를 매개변수에 추가
//		//addAttribute를 통해 모델에 담아준다
//		model.addAttribute("board_list", list);
//		return "board/list";
//	}
	
	//페이징 목록 화면 처리
	@RequestMapping("/list")
	public String list(Model model, Criteria cri) {
		
		//페이징 된 게시글 목록 가져오기
		ArrayList<BoardVO> list = service.getList(cri);
		//모델에 추가
		model.addAttribute("board_list", list);
		//전체 게시글 수 가져오기
		//select count(*) as total from tbl_board;
		int total = service.getTotal();
		System.out.println(total);
		
		//new PageVO(기준, 전체게시글 수);
		model.addAttribute("pageMaker", new PageVO(cri, total));
		
		
		return "board/list";
		//처리 했다면 list.jsp 화면처리
	}
	
	//등록 화면처리(GET방식)
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String register() {
		
		return "board/register";
	}
	//등록 폼처리(POST)
	@RequestMapping(value = "/register",method=RequestMethod.POST)
	public String register(BoardVO vo) {
		service.register(vo);
		return "redirect:/board/list";//기본적으로 forward형식이다
	}
	
//	//상세보기 화면처리
//	@RequestMapping("/content")
//	public String content(@RequestParam("num") int num,
//			Model model) {//선언당시 데이터타입을 정해주면 형변환을 해서 온다
//		
//		BoardVO vo = service.getContent(num);
//		
//		model.addAttribute("board_content", vo);
//		
//		return "board/content";
//	}
//	//변경 화면처리
//	@RequestMapping("/modify")
//	public String modify(@RequestParam("num") int num,
//			Model model) {
//		
//		BoardVO vo = service.getContent(num);
//		model.addAttribute("board_content", vo);
//		return "board/modify";
//	}
	
	//기능이 동일한 메소드를 하나로 통합
	//상세보기와 수정을 한번에 사용하기.
	//void 형태로 만들기 (요청된 데이터 타입에 맞춰서 알아서 보내준다)
	//RequestMapping의 중괄호를 통해 여러개를 보낼수 잇다
	@RequestMapping({"/content", "/modify"})
	public void content(@RequestParam("num")int num, Model model, @ModelAttribute("cri") Criteria cri) {//8. 컨트롤러에서는 pageNum과, count를 받을 수 있도록 처리한 후 -> content.jsp 변경"
			
		
		BoardVO vo = service.getContent(num);
		model.addAttribute("board_content", vo);
		//void 형태의 메서드는 요청받은 페이지를 리졸버 뷰에 전송한다
	}
	

	//update요청
	//수정 완료 버튼
	//1. update요청을 받을 수 있는 메서드 생성
	//2. service계층에 잔달 받은 폼값을 전달받는 update(vo) 메서드를 생성
	//3. service update() 메서드 안에서는 myBatis로 연결하는 BoardUpdate(vo) 메서드를 생성
	//4. <update> 태그에는 파라미터타입으로 BoardVO를 받습니다.
	//5. 업데이트 후에는 list화면으로 이동
	//sql = update tbl_board set content=#{ }, title=#{ }, updatedate = current_timestamp 
	// 			where num = #{}
		
	//게시판 수정 완료 버튼
	//1.컨트롤러 작성후 service계층 인터페이스 메서드 생성)
	//2.serviceImpl 에서 메서드 오버라이딩
	//3.마이바티스 mapper인터페이스 메서드 생성
	//4.mapper.xml 쿼리문 생성
	@RequestMapping("/update")
	public String update(BoardVO vo) {

		service.update(vo);


		return "redirect:/board/list";
	}
	
	//delete요청
	//quiz
	//1. service계층에 num을 전달받는 delete(?) 을 생성하세요
	//2. mapper인터페이스에 void deleteBoard(?) 를 선언하세요
	//3. service안에서는 mapper에 선언된 deleteBoard(?) 를 실행합니다.
	//4. mapper.xml에서는 <delete></delete> 태그를 통해 삭제를 진행하세요
	//5. sql = delete from tbl_board where num = #{num}
	
	//게시판 삭제 (modify.jsp의 삭제 버튼 링크 확인하세요)
	@RequestMapping("/delete")
	public String delete(@RequestParam("num") int num) {

		service.delete(num);

		return "redirect:/board/list";

	}
	
}
