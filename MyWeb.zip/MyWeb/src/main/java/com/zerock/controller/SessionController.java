package com.zerock.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/session/*")
public class SessionController {
	//해당 컨트롤러는 세션 연습 컨트롤러
	
	//1.main페이지 화면처리
	@RequestMapping("/mainPage")
	public String mainPage() {
		return "session/mainPage";
	}
	
	//2.login페이지 화면처리
	@RequestMapping("/loginPage")
	public String loginPage() {
		return "session/loginPage";
	}
	
	//3.마이 페이지
	@RequestMapping("/myPage")
	public String myPage(HttpSession session) {
		
//		//8.마이페이지 접근 막기
//		//세션에 정보가 없다면, 페이지 접근할수 없도록 강제 페이지 이동시킴
//		if(session.getAttribute("user_id") == null) {
//			return "redirect:/session/loginPage";
//		}
		
		return "session/myPage";
	}
	
	//4.정보 수정 페이지
	@RequestMapping("/updatePage")
	public String updatePage() {
		return "session/updatePage";
	}
	
	//5.로그인 폼 요청처리
	@RequestMapping("/sessionForm")
	public String sessionForm(@RequestParam("id") String id,
			@RequestParam("pw") String pw,
			HttpSession session,
			RedirectAttributes RA
			) { //스프링에서 세션을 사용하는 방법 
		
		
		//6. 아이디가 abc, 비밀번호가 1234라면 로그인 성공이라 가정
		if(id.equals("abc") && pw.equals("1234")) {
			session.setAttribute("user_id", id); //세션에 아이디 저장
			session.setAttribute("user_name", "홍길자"); //세션에 이름 저장
			
			return "redirect:/session/myPage";
		} else {
			//model.addAttribute("변수명", "값");
			RA.addFlashAttribute("msg", "아이디 패스워드를 확인하실래요?");
			return "redirect:/session/loginPage";
		}
		
	}
	
	//7.로그아웃
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		
		session.removeAttribute("user_id"); //특정세션삭제
		session.invalidate(); //모든 세션 삭제
		
		return "redirect:/session/mainPage";
	}
}
	
	
	
	
