package com.zerock.board.command;

public class PageVO {
//	1. total : 게시글의 전체 개수
//	2. endPage : 게시판 화면에 보여질 마지막 번호
//	3. startPage : 게시판 화면에 보여질 시작 번호
//	4. realEnd : 게시판에 실제 마지막 번호
//	5. prev : 이전페이지 활성화 여부
//	6. next : 다음페이지 활성화 여부
	
	private int total;
	private int endPage;
	private int startPage;
	
	private boolean prev, next;
	
	private Criteria cri; //기준
	
	//생성자
	//생성자에서는 total, Criteria 기준을 받아서 화면에 보여줘야 할 변수를 계산
	public PageVO(Criteria cri , int total) {
		this.cri = cri; //기준
		this.total = total; //총 페이지 수
		
		//화면에 보여질 끝페이지
		//현재 조회하고 있는 페이지가 11번 -> 화면에 보여져야 하는 끝 페이지 20
		//현재 조회하고 있는 페이지가 5번 -> 화면에 보여져야 하는 끝 페이지 10
		//공식 :(int)Math.ceil(페이지 번호 / 한번에 보여질 페이지 개수) * 한번에 보여질 페이지 개수
		this.endPage = (int)Math.ceil(cri.getPageNum()/10.0)*10;
		
		//시작 페이지
		//공식 : endPage - 한번에 보여질 페이지 수 +1;
		this.startPage = endPage -9;
		
		//실제 마지막 페이지 번호
		//만약 총 게시글이 52개밖에 없으면 ? -> endPage는 6까지 나와야함
		//만약 총 게시글이 81개밖에 없으면 ? -> endPage는 9까지 나와야함
		//만약 총 게시글이 105개밖에 없으면 ? -> endPage는 11까지 나와야함
		//11번 클릭시 -> endPage의 공식으로 가면 ->11,12,13,14...20까지 표시됨
		
		//실제 보여져야 하는 끝번호를 구해서 비교
		//공식 : 실제 끝번호 = 전체게시글 수 / 몇개의 페이지를 보여주는지(실수형)
	
		int realEnd = (int)Math.ceil( total/(double)cri.getCount());
		
		//ex : 131개의 게시물
		//1번 페이지 클릭시 -> endPage의 공식은 10, realEnd =14
		//실제 보여져야 하는 번호 =10
		//11번 페이지 클릭시 -> endPage의 송식은 20, realEnd =14
		//실제 보여져야 하는 번호 = 14
		
		//ex : 51개의 게시물
		//1번 페이지 클릭시 -> endPage의 공식은 10, realEnd =6
		//실제 보여져야 하는 번호 =6
		
		//결론: endPage > realEnd 크다면 realEnd를 보여주면됨
		if(this.endPage > realEnd) {
			this.endPage = realEnd;
		}
		
		//startPage 1,11,21,31,41,101...으로 표시가됨
		//이전버튼 (startPage가 1보다 큰 경우만 true) -> 버튼 활성화
		this.prev = this.startPage > 1;
		
		//다음 버튼 
		//다음버튼 (realEnd가 endPage)보다 큰 경우만 활성화(위에 참고)
		this.next = realEnd > endPage; //버튼 활성화

		System.out.println("[endPage]"+endPage);
		System.out.println("[startPage]"+startPage);
		
		//이후에 list에 대한 요청 처리.
	}
	//getter,setter

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public boolean isPrev() {
		return prev;
	}

	public void setPrev(boolean prev) {
		this.prev = prev;
	}

	public boolean isNext() {
		return next;
	}

	public void setNext(boolean next) {
		this.next = next;
	}

	public Criteria getCri() {
		return cri;
	}

	public void setCri(Criteria cri) {
		this.cri = cri;
	}
	
}
