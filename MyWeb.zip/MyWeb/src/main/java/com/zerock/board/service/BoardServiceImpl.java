package com.zerock.board.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zerock.board.command.BoardVO;
import com.zerock.board.command.Criteria;
import com.zerock.board.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {

	
	@Autowired
	BoardMapper mapper;
	
	@Override
	public void register(BoardVO vo) {
		mapper.insertBoard(vo);
	}

//	@Override
//	public ArrayList<BoardVO> getList() {
//	
//		ArrayList<BoardVO> list = mapper.getList();
//		
//		return list;
//	}

	//페이징된 게시글 구하는 메서드
	@Override
	public ArrayList<BoardVO> getList(Criteria cri) {
		
		ArrayList<BoardVO> list = mapper.pageingList(cri);
		
		return list;
	}
	
	//전체 게시글 수
	public int getTotal() {
		
		int total =mapper.getTotal();
		return total;
	}
	
	@Override
	public BoardVO getContent(int num) {
		
		//1. getContent() 메서드를 마이바티스 인터페이스에 선언
		//2. xml파일에서 select 태그에 id값으로 사용
		//3. 결과를 반환 받아서, 컨트롤러에서는 model에 board_content라는 이름으로 저장하고 화면으로 이동
		BoardVO vo = mapper.getContent(num);
		return vo;
	}
	
	//게시물 수정 완료 버튼
		@Override
		public void update(BoardVO vo) {

			boolean bool = mapper.updateBoard(vo);
			System.out.println("성공실패?" + bool);
		}
		
		//게시판 삭제 메서드
		@Override
		public void delete(int num) {

			mapper.deleteBoard(num);
		}

		


}
