package com.zerock.board.command;

public class Criteria {

	//페이징 쿼리 : select * from tbl_board order by num desc limit x, y
	//페이징의 기준을 설정하는 클래스
	
	private int pageNum; //현재 조회하는 페이지 번호
	private int count; //몇개의 데이터를 보여줄건가
	

	//생성자
	public Criteria() {
		//최초 게시판에 들어갈 때 기본으로 1번 페이지, 10개의 데이터 세팅
		this.pageNum = 1;
		this.count =10;
	}
	public Criteria(int pageNum, int count) {
		// 사용자가 클릭시 값을 전달받아서 페이지 기준을 설정함
		this.pageNum = pageNum;
		this.count =count;
	}
	//limit구문에 시작위치에 지정할 메서드
	//limit x, count 구문에 전달될 x를 구하는 메서드
	public int getPageStart() {
		//1번 페이지 클릭시 limit 0, 10의 형태
		//2번 페이지 클릭시 limit 10, 10의 형태
		//3번 페이지 클릭시 limit 20, 10의 형태
		return (pageNum-1) * count;
	}
	
	//getter, setter생성
	
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
