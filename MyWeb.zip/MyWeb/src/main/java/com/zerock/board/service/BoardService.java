package com.zerock.board.service;

import java.util.ArrayList;

import com.zerock.board.command.BoardVO;
import com.zerock.board.command.Criteria;


public interface BoardService {
	
	//1. 해당 인터페이스를 구현하는 BoardServiceImpl 클래스를 생성합니다
	//2. 등록처리하는 register()생성
	//3. 컨트롤러에서 등록요청이 들어오면 register()메서드로 연결되도록 처리


	
	public void register(BoardVO vo); //등록 처리
	//public ArrayList<BoardVO>  getList();//모든 게시글을 조회하는 메서드
	public ArrayList<BoardVO> getList(Criteria cri);
	public BoardVO getContent(int num);
	public int getTotal(); //전체 게시글 수
	//quiz
	public void update(BoardVO vo); //게시물 수정 완료버튼
	public void delete(int num); //게시물 삭제 메서드
	
	
}
