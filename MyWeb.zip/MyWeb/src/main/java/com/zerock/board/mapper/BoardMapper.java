package com.zerock.board.mapper;

import java.util.ArrayList;

import com.zerock.board.command.BoardVO;
import com.zerock.board.command.Criteria;

public interface BoardMapper {
	
	//xml에서 사용할 메서드를 추상메서드로 생성
	public void insertBoard(BoardVO vo);//등록 메서드
	//public ArrayList<BoardVO> getList();//모든 게시물 조회
	public ArrayList<BoardVO> pageingList(Criteria cri);//페이징된 게시물 조회
	public BoardVO getContent(int num);//게시글 상세보기
	public int getTotal(); //전체 게시글 수
	//quiz
	public boolean updateBoard(BoardVO vo); //게시물 수정완료 버튼
	public void deleteBoard(int num); //게시판 삭제 메서드
}
