package kr.co.koo.board.model;

import java.sql.*;
import java.util.*;
import javax.naming.*;
import javax.sql.DataSource;

public class BoardDAO {

	private static BoardDAO dao = new BoardDAO();
	
	private DataSource ds;
	
	private BoardDAO() {
		try {// 연결 풀 사용하기
			Context ct = new InitialContext();
			ds = (DataSource)ct.lookup("java:comp/env/jdbc/mysql");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static BoardDAO getInstance() {
		if(dao == null) {
			dao = new BoardDAO();
		}
		return dao;
	}
	
	//게시글 내용을 DB에 저장하는 메서드
	public void write(String bName, String bTitle, String bContent) {
		String sql = "INSERT INTO board(board_name, board_title, board_content)"
					+ " VALUES (?,?,?)";
		Connection conn =null;
		PreparedStatement pstmt = null;
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, bName);
			pstmt.setString(2, bTitle);
			pstmt.setString(3, bContent);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close(); 
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	//모든 게시글의 정보를 DB로부터 얻어올 메서드(NEW)
	public List<BoardVO> getBoardList(){
		
		List<BoardVO> articleList = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM board ORDER BY board_id DESC";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {//모든 게시물이 담길때 까지 반복한다
				BoardVO article = new BoardVO(rs.getInt("board_id"),
											  rs.getString("board_name"),
											  rs.getString("board_title"),
											  rs.getString("board_content"),
											  rs.getTimestamp("board_date"),
											  rs.getInt("board_hit"));
				articleList.add(article);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close(); 
				pstmt.close();
				rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	return articleList;	
	}
	
	//특정 게시글의 정보를 db로부터 얻어오는 메서드(new)
	public BoardVO getBoardContent(String strBId) {//매개변수로 글번호로 받아와야 한다
		
		upHit(strBId);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		BoardVO board = null;
		
		String sql = "SELECT * FROM board WHERE board_id=?";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(strBId));
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int bId = rs.getInt("board_id");
				String bName = rs.getString("board_name");
				String bTitle = rs.getString("board_title");
				
				String bContent = rs.getString("board_content");
				bContent.replace("\r\n", "<br/>");
				bContent.replace("\u0020", "&nbsp;");
				Timestamp bDate = rs.getTimestamp("board_date");
				int bHit = rs.getInt("board_hit");
				
				board = new BoardVO(bId, bName, bTitle,bContent,bDate,bHit);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close(); 
				pstmt.close();
				rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
	}
		return board;
	}
	
	//글 제목을 클릭 할때 마다 조회수를 상승시키는 메서드	
	private void upHit(String strBId) {
		
		
		
		String sql = "UPDATE board SET board_hit = board_hit+1 "
					+"WHERE board_id=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {	
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(strBId));
				pstmt.executeUpdate();
				
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close(); 
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	//게시판 수정양식에 원본글데이터를 가져올 메서드
	   public BoardVO updateView(String bNum) {

	      String sql = "select * from board where board_id=?";

	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;

	      BoardVO article = null;

	      try {
	         conn = ds.getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setInt(1, Integer.parseInt(bNum));
	         rs = pstmt.executeQuery();

	         if(rs.next()) {
	            int bNo = rs.getInt("board_id");
	            String bName = rs.getString("board_name");
	            String bTitle = rs.getString("board_title");
	            String bContent = rs.getString("board_content");
	            Timestamp bDate = rs.getTimestamp("board_date");
	            int bHit = rs.getInt("board_hit");

	            article = new BoardVO(bNo, bName, bTitle, bContent, bDate, bHit);
	         }

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            conn.close(); pstmt.close(); rs.close();
	         } catch (Exception e2) {
	            e2.printStackTrace();
	         }
	      }

	      return article;
	   }
	   
	 //게시글을 DB에 수정처리하는 메서드
	   public void updateArticle(String bNum, String bTitle, String bContent) {

	      String sql = "update board set board_title=?, "
	            + "board_content=? where board_id=?";

	      Connection conn = null;
	      PreparedStatement pstmt = null;

	      try {
	         conn = ds.getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, bTitle);
	         pstmt.setString(2, bContent);
	         pstmt.setInt(3, Integer.parseInt(bNum));

	         pstmt.executeUpdate();

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            conn.close(); pstmt.close();
	         } catch (Exception e2) {
	            e2.printStackTrace();
	         }
	      }
	   }
	   
	 //게시글 삭제 메서드
	   public void deleteArticle(String bNum) {

	      Connection conn = null;
	      PreparedStatement pstmt = null;

	      String sql = "delete from board where board_id=?";

	      try {
	         conn = ds.getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setInt(1, Integer.parseInt(bNum));

	         pstmt.executeUpdate();

	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            conn.close(); pstmt.close();
	         } catch (Exception e2) {
	            e2.printStackTrace();
	         }
	      }

	   }
	  
}
