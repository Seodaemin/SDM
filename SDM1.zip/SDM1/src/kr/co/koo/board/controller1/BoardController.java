package kr.co.koo.board.controller1;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.koo.board.model.BoardDAO;
import kr.co.koo.board.service.BoardContentService;
import kr.co.koo.board.service.BoardDeleteService;
import kr.co.koo.board.service.BoardListService;
import kr.co.koo.board.service.BoardUpdateService;
import kr.co.koo.board.service.BoardUpdateViewService;
import kr.co.koo.board.service.BoardWriteService;
import kr.co.koo.board.service.IBoardService;


@WebServlet("*.board")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public BoardController() {
        super();
       
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doRequest(request,response);
	}

	private void doRequest(HttpServletRequest request, HttpServletResponse response) 
												throws ServletException, IOException{
		//doGet 과 doPost를 한곳에서 처리하기 위해사용(한번만 작성)
		request.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		String ui = null; //jsp파일의 경로 주소를 저장할 변수.
		IBoardService sv = null;
		
		if(uri.equals("/hong/board/BList.board")) {
			sv = new BoardListService();//new
			sv.execute(request, response);//new
			ui = "/board/board_list.jsp";//파일의 경로를 적어준다
		}else if(uri.equals("/hong/board/BWriteView.board")) {
			ui = "/board/board_write_view.jsp";
		}else if(uri.equals("/hong/board/BWrite.board")) {
			sv = new BoardWriteService();
			sv.execute(request, response);
			ui = "/board/BList.board";
		}else if(uri.equals("/hong/board/BContent.board")) {
			sv = new BoardContentService();
			sv.execute(request, response);
			ui = "/board/board_content_view.jsp";
		}else if(uri.equals("/hong/board/BUpdateView.board")) {
			sv = new BoardUpdateViewService();
			sv.execute(request, response);
			ui = "/board/board_update_view.jsp";
		}else if(uri.equals("/hong/board/BUpdate.board")) {
			sv = new BoardUpdateService();	
			sv.execute(request, response);
			ui = "/board/BList.board";
		}else if(uri.equals("/hong/board/BDelete.board")) {
			sv = new BoardDeleteService();	
			sv.execute(request, response);
			ui = "/board/BList.board";
		}
		
		//페이지 강제이동 forward 방식 sendredirect와 다르게 리퀘스트 정보를 가지고 이동할때 사용
		RequestDispatcher dp = request.getRequestDispatcher(ui);
		dp.forward(request,response);
		
		
		
	}

}
