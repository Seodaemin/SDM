package kr.co.koo.board.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.koo.board.model.BoardDAO;

public class BoardUpdateService implements IBoardService {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
	
		String bNum = req.getParameter("bId");
		String bTitle = req.getParameter("bTitle");
		String bContent = req.getParameter("bContent");
		
		BoardDAO dao = BoardDAO.getInstance();
		dao.updateArticle(bNum,bTitle,bContent);
		

	}

}
