package kr.co.koo.board.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.koo.board.model.BoardDAO;
import kr.co.koo.board.model.BoardVO;

public class BoardUpdateViewService implements IBoardService {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		//요청 파라미터 처리
		String bNum = req.getParameter("bId");
		//DAO객체 생성 후 알맞은 메서드 호출
		BoardDAO dao = BoardDAO.getInstance();
		BoardVO article = dao.updateView(bNum);
		//ui에서 EL이필요하면 request나 session객체에 필요 데이터 셋팅
		req.setAttribute("article",article);

	}

}
