package kr.co.koo.board.service;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.koo.board.model.BoardDAO;
import kr.co.koo.board.model.BoardVO;

public class BoardListService implements IBoardService {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		BoardDAO dao = BoardDAO.getInstance();
		List<BoardVO> articleList = dao.getBoardList();
		req.setAttribute("article", articleList);
	}

}
