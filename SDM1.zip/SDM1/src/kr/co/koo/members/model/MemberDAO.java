package kr.co.koo.members.model;

import java.sql.*;
import javax.naming.*;
import javax.sql.DataSource;

import java.util.*;

public class MemberDAO {//정렬할때 ctrl +a  ctrl+i

	private static MemberDAO dao = new MemberDAO();//싱글객체 생성
	private DataSource ds;	

	//회원관리에 필요한 상수 선언.
	public static final int JOIN_SUCCESS = 1;
	public static final int JOIN_FAIL = 0;

	public static final int MEMBER_DUPLICATE = 1;
	public static final int MEMBER_NON_DUPLICATE = 0;

	public static final int LOGIN_SUCCESS = 1;
	public static final int LOGIN_FAIL_ID = 0;
	public static final int LOGIN_FAIL_PW = -1;

	public static final int UPDATE_SUCCESS = 1;
	public static final int UPDATE_FAIL = 0;

	public static final int DELETE_SUCCESS = 1;
	public static final int DELETE_FAIL = 0;

	//어떠한 객체든지 똑같은 상수가 되어야 하기 때문에, 외부참조도 가능
	private MemberDAO() {
		//외부에서 생성자를 만들지 못하도록 한다
		try {
			//crtl+space 로 try~ catch문을 만든다
			Context ct = new InitialContext();
			ds = (DataSource)ct.lookup("java:comp/env/jdbc/mysql");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static MemberDAO getInstance() {
		if(dao!=null) {//dao가 생성되지 않았을 경우(안전장치)
			dao = new MemberDAO();
		}
		return dao;
	}//여기까지가 DAO 기본설계

	//회원가입을 실행하는 메서드
	public int insertMember(MemberVO member) {
		int rn = JOIN_FAIL;

		String sql = "INSERT INTO members "
				+ "(user_id, user_pw, user_name, user_email, user_address) "
				+ "VALUES (?,?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPw());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getEmail());
			pstmt.setString(5, member.getAddress());

			int i = pstmt.executeUpdate();

			if(i == 1) {
				rn = JOIN_SUCCESS;
			} else {
				rn = JOIN_FAIL;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close(); pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}		
		return rn;
	}

	//ID 중복확인을 하는 메서드 선언.
	public int confirmId(String id) {
		int rn = MEMBER_DUPLICATE;

		String sql = "SELECT user_id FROM members "
				+ "WHERE user_id=?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				rn = MEMBER_DUPLICATE;
			} else {
				rn = MEMBER_NON_DUPLICATE;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close(); pstmt.close(); rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}		

		return rn;
	}

	//로그인의 유효성을 검증하는 메서드 선언.
	public int userCheck(String id, String pw) {
		int rn = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select user_pw from members "
				+ "where user_id=?";

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				String dbPw = rs.getString("user_pw");
				if(pw.equals(dbPw)) {
					rn = LOGIN_SUCCESS;
				}else {
					rn = LOGIN_FAIL_PW;
				}
			}else {
				rn = LOGIN_FAIL_ID;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close(); pstmt.close(); rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return rn;
	}

	//로그인한 회원의 정보를 DB로부터 가져오는 메서드 선언.
	public MemberVO getMemberInfo(String id) {

		String sql = "select * from members "
				+ "where user_id=?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		MemberVO vo = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				String userId = rs.getString("user_id");
				String pw = rs.getString("user_pw");
				String name = rs.getString("user_name");
				String email = rs.getString("user_email");
				String address = rs.getString("user_address");
				Timestamp rDate = rs.getTimestamp("user_reg_date");

				vo = new MemberVO(userId, pw, name, email, address, rDate);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close(); pstmt.close(); rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return vo;
	}

	//비밀번호 변경 메서드
	public int changePassword(String pw, String id) {

		int rn = 0;

		String sql = "update members set user_pw=? "
				+ "where user_id=?";
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pw);
			pstmt.setString(2, id);

			int i = pstmt.executeUpdate();

			if(i == 1) {
				rn = UPDATE_SUCCESS;
			} else {
				rn = UPDATE_FAIL;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close(); pstmt.close(); 
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return rn;
	}

	//회원정보 수정을 처리하는 메서드
	public int updateUser(MemberVO member) {
		int rn = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update members set user_name=?, "
				+ "user_email=?, user_address=? "
				+ "where user_id=?";

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getName());
			pstmt.setString(2, member.getEmail());
			pstmt.setString(3, member.getAddress());
			pstmt.setString(4, member.getId());

			int i = pstmt.executeUpdate();

			if(i == 1) {
				rn = UPDATE_SUCCESS;
			}else {
				rn = UPDATE_FAIL;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close(); pstmt.close(); 
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return rn;
	}

	//회원탈퇴를 처리하는 메서드 선언.
	public int deleteUser(String id) {

		int rn = 0;

		String sql = "delete from members where user_id=?";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			int i = pstmt.executeUpdate();

			if(i == 1) {
				rn = DELETE_SUCCESS;
			} else {
				rn = DELETE_FAIL;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close(); pstmt.close(); 
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return rn;
	}

}




