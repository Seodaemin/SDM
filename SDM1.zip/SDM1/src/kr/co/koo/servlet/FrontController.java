package kr.co.koo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("*.hello")//.do로 포함되는 url을 모두 다 받는다 (확장자 url)
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public FrontController() {
        super();
     
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("get요청 발생!");
		
		String uri = request.getRequestURI();
		System.out.println("uri:"+uri);
		//model1과 다르게 모든 요청을 하나의 서블릿에서 가능하다
		if(uri.equals("hong/join.hello")) {
			System.out.println("회원가입 요청이 들어옴!");
		}else if(uri.equals("hong/login.hello")){
			System.out.println("로그인 요청이 들어옴!");
		}else if(uri.equals("hong/update.hello")){
			System.out.println("정보수정 요청이 들어옴!");
		}else if(uri.equals("hong/delete.hello")){
			System.out.println("회원탈퇴 요청이 들어옴!");
		}
		
		System.out.println("회원가입 요청이 들어옴!");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
