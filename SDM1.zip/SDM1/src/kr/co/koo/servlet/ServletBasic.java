package kr.co.koo.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//URL 매핑 : 컨트롤러를 사용하여 URL을 사용자 정의로 지정하는 방식
@WebServlet("/apple")
public class ServletBasic extends HttpServlet {
	//서블릿의대해 일단 공부!
	//서블릿 클래스 선언 방법 : HttpServlet 클래스를 상속 받습니다
	

	
	public ServletBasic() {
		System.out.println("서블릿 객체 생성!");
	}//기본 생성자 선언

	@Override
	public void init() throws ServletException {
		// 요청이 들어왔을때 처음에 실행할 로직 작성
		// init()메서드는 컨테이너에 의해 서블릿 객체 생성시 자동 호출됩니다(최초1회)
		System.out.println("init메서드 호출!!");
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Http Get요청이 들어왔을때 호출 되는 메서드
		System.out.println("doGet 메서드 호출!!");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Http Post요청이 들어왔을때 호출 되는 메서드
		System.out.println("doPost 메서드 호출!!");
	}

	@Override
	public void destroy() {
		//서블릿 객체가 소멸할때 호출되는 메서드(객체 소멸시 1회 호출)
		System.out.println("destroy 메서드 호출");
	}

	//HttpServlet클래스에서 상속받은 메서드들을 오버라이딩 합니다
	//init(), doGet(), doPost(), destroy()
	//alt+shif+space Override/Implement Method클릭
	
}
